# Heroes of the Bible - Arena of Faith

Phase 0 + Phase 1 (greybox prototype). Godot 4.2+ / GDScript / Compatibility renderer.

## Open and run
1. Install Godot 4.2 or newer (standard build, not .NET).
2. Godot Project Manager -> Import -> select `project.godot`.
3. Open it once in the editor (this registers the `Fighter`, `Hud`, `InputSetup` classes), then press F5.

## Controls (desktop test)
A/D (or arrows) move, W/Up/Space jump, J light attack, R or Enter restart.

## Status
Written but NOT yet run in Godot. No APK has been built or tested.
