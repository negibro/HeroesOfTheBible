class_name Fighter
extends CharacterBody2D
## Phase 1 greybox fighter: walk, jump, light attack, takes hits.
## Drawn with simple shapes. Origin (0,0) is at the fighter's feet.

signal health_changed(current, maximum)
signal died(fighter)

enum State { IDLE, WALK, JUMP, ATTACK, HITSTUN, KO }

const BODY_W := 60.0
const BODY_H := 120.0

# --- Tunable stats (will move into resources in Phase 4) ---
@export var fighter_name: String = "Fighter"
@export var max_health: int = 100
@export var walk_speed: float = 220.0
@export var jump_velocity: float = -450.0
@export var gravity: float = 1400.0
@export var body_color: Color = Color(0.5, 0.6, 0.35)
@export var is_player: bool = true

@export_group("Light attack")
@export var light_damage: int = 8
@export var light_startup: float = 0.08   # seconds before hitbox is active
@export var light_active: float = 0.10    # seconds hitbox is active
@export var light_recovery: float = 0.18  # seconds after active frames
@export var light_reach: float = 70.0
@export var light_knockback: float = 260.0
@export var hitstun_duration: float = 0.28

@export var show_debug_boxes: bool = true

var opponent: Fighter = null
var arena_left: float = 0.0
var arena_right: float = 1280.0
var input_enabled: bool = true

var state: State = State.IDLE
var health: int = 100
var facing: int = 1

var _attack_time: float = 0.0
var _attack_has_hit: bool = false
var _hitstun_left: float = 0.0
var _flash_time: float = 0.0


func _ready() -> void:
    collision_layer = 2   # fighters
    collision_mask = 1    # collide with the floor only (fighters pass through each other)
    var shape := RectangleShape2D.new()
    shape.size = Vector2(BODY_W, BODY_H)
    var col := CollisionShape2D.new()
    col.shape = shape
    col.position = Vector2(0.0, -BODY_H * 0.5)
    add_child(col)
    health = max_health
    health_changed.emit(health, max_health)


func _physics_process(delta: float) -> void:
    velocity.y += gravity * delta

    match state:
        State.IDLE, State.WALK, State.JUMP:
            _process_free()
        State.ATTACK:
            _process_attack(delta)
        State.HITSTUN:
            _process_hitstun(delta)
        State.KO:
            velocity.x = move_toward(velocity.x, 0.0, 1500.0 * delta)

    move_and_slide()
    position.x = clampf(position.x, arena_left + BODY_W * 0.5, arena_right - BODY_W * 0.5)


func _process(delta: float) -> void:
    if _flash_time > 0.0:
        _flash_time -= delta
    queue_redraw()


# ---------------------------------------------------------------- states

func _process_free() -> void:
    var dir := 0.0
    if is_player and input_enabled:
        dir = Input.get_axis("p1_left", "p1_right")
        if Input.is_action_just_pressed("p1_jump") and is_on_floor():
            velocity.y = jump_velocity
        if Input.is_action_just_pressed("p1_light") and is_on_floor():
            _start_light_attack()
            return

    velocity.x = dir * walk_speed
    _update_facing()

    if not is_on_floor():
        state = State.JUMP
    elif absf(dir) > 0.01:
        state = State.WALK
    else:
        state = State.IDLE


func _start_light_attack() -> void:
    state = State.ATTACK
    _attack_time = 0.0
    _attack_has_hit = false
    velocity.x = 0.0


func _process_attack(delta: float) -> void:
    _attack_time += delta
    velocity.x = move_toward(velocity.x, 0.0, 2000.0 * delta)

    if _attack_is_active():
        _try_hit()

    if _attack_time >= light_startup + light_active + light_recovery:
        state = State.IDLE


func _process_hitstun(delta: float) -> void:
    _hitstun_left -= delta
    velocity.x = move_toward(velocity.x, 0.0, 1200.0 * delta)
    if _hitstun_left <= 0.0:
        state = State.IDLE


# ---------------------------------------------------------------- combat

func _attack_is_active() -> bool:
    return state == State.ATTACK \
        and _attack_time >= light_startup \
        and _attack_time < light_startup + light_active


func _try_hit() -> void:
    # An attack instance can hit its target at most once.
    if _attack_has_hit or opponent == null:
        return
    if _attack_rect_global().intersects(opponent.get_hurtbox_rect()):
        _attack_has_hit = true
        opponent.take_hit(light_damage, facing, light_knockback)


func take_hit(damage: int, push_dir: int, knockback: float) -> void:
    if state == State.KO:
        return
    health = maxi(health - damage, 0)
    health_changed.emit(health, max_health)
    _flash_time = 0.12

    if health == 0:
        state = State.KO
        velocity = Vector2(push_dir * knockback, -200.0)
        died.emit(self)
        return

    state = State.HITSTUN
    _hitstun_left = hitstun_duration
    velocity.x = push_dir * knockback


func get_hurtbox_rect() -> Rect2:
    return Rect2(global_position + Vector2(-BODY_W * 0.5, -BODY_H), Vector2(BODY_W, BODY_H))


func _attack_rect_local() -> Rect2:
    var x0 := BODY_W * 0.5
    if facing < 0:
        x0 = -BODY_W * 0.5 - light_reach
    return Rect2(x0, -BODY_H * 0.75, light_reach, 36.0)


func _attack_rect_global() -> Rect2:
    var r := _attack_rect_local()
    return Rect2(global_position + r.position, r.size)


func _update_facing() -> void:
    if opponent == null or not is_on_floor():
        return
    var dx := opponent.global_position.x - global_position.x
    if absf(dx) > 4.0:
        facing = 1 if dx > 0.0 else -1


# ---------------------------------------------------------------- drawing

func _draw() -> void:
    var col := body_color
    if _flash_time > 0.0:
        col = Color.WHITE

    if state == State.KO:
        draw_set_transform(Vector2(0.0, -BODY_W * 0.5), -facing * PI * 0.5)

    # body
    draw_rect(Rect2(-BODY_W * 0.5, -BODY_H, BODY_W, BODY_H), col)
    # head + eye (shows facing)
    draw_circle(Vector2(0.0, -BODY_H - 18.0), 20.0, col.lightened(0.15))
    draw_circle(Vector2(facing * 10.0, -BODY_H - 22.0), 4.0, Color.BLACK)

    if state == State.KO:
        return

    # arm: short normally, extended while the attack is active
    var arm_len := 22.0
    if _attack_is_active():
        arm_len = BODY_W * 0.5 + light_reach
    var arm_x := 0.0 if facing > 0 else -arm_len
    draw_rect(Rect2(arm_x, -BODY_H * 0.75 + 8.0, arm_len, 18.0), col.darkened(0.25))

    # debug hitbox / hurtbox outlines
    if show_debug_boxes:
        draw_rect(Rect2(-BODY_W * 0.5, -BODY_H, BODY_W, BODY_H), Color(0.2, 0.6, 1.0, 0.8), false, 1.5)
        if _attack_is_active():
            draw_rect(_attack_rect_local(), Color(1.0, 0.9, 0.2, 0.45), true)
