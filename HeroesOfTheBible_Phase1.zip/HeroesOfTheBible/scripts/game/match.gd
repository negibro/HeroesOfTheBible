extends Node2D
## Phase 1 greybox match: one player vs. one stationary training dummy.
## Builds the arena, fighters, camera and HUD in code.

const ARENA_LEFT := 60.0
const ARENA_RIGHT := 1220.0
const FLOOR_Y := 600.0

var player: Fighter
var dummy: Fighter
var hud: Hud


func _ready() -> void:
    InputSetup.register()
    _build_arena()
    _build_fighters()

    hud = Hud.new()
    add_child(hud)
    hud.setup(player, dummy)


func _process(_delta: float) -> void:
    if Input.is_action_just_pressed("restart"):
        get_tree().reload_current_scene()


func _build_arena() -> void:
    # Oversized rectangles so wider/taller phone screens never show empty space.
    var sky := ColorRect.new()
    sky.color = Color(0.93, 0.82, 0.62)
    sky.position = Vector2(-2000.0, -1500.0)
    sky.size = Vector2(5300.0, 1500.0 + FLOOR_Y)
    add_child(sky)

    var ground := ColorRect.new()
    ground.color = Color(0.72, 0.62, 0.47)
    ground.position = Vector2(-2000.0, FLOOR_Y)
    ground.size = Vector2(5300.0, 1500.0)
    add_child(ground)

    var line := ColorRect.new()
    line.color = Color(0.35, 0.25, 0.15)
    line.position = Vector2(-2000.0, FLOOR_Y - 3.0)
    line.size = Vector2(5300.0, 6.0)
    add_child(line)

    var floor_body := StaticBody2D.new()
    floor_body.collision_layer = 1
    floor_body.collision_mask = 0
    floor_body.position = Vector2(640.0, FLOOR_Y + 100.0)
    var floor_shape := CollisionShape2D.new()
    var rect := RectangleShape2D.new()
    rect.size = Vector2(5300.0, 200.0)
    floor_shape.shape = rect
    floor_body.add_child(floor_shape)
    add_child(floor_body)

    # Camera centered on the 1280x720 design area; extra screen space is shown evenly.
    var cam := Camera2D.new()
    cam.position = Vector2(640.0, 360.0)
    add_child(cam)


func _build_fighters() -> void:
    player = Fighter.new()
    player.fighter_name = "Player (greybox)"
    player.is_player = true
    player.body_color = Color(0.45, 0.55, 0.30)
    player.position = Vector2(400.0, FLOOR_Y)

    dummy = Fighter.new()
    dummy.fighter_name = "Training Dummy"
    dummy.is_player = false
    dummy.max_health = 120
    dummy.body_color = Color(0.70, 0.40, 0.28)
    dummy.position = Vector2(880.0, FLOOR_Y)

    for f in [player, dummy]:
        f.arena_left = ARENA_LEFT
        f.arena_right = ARENA_RIGHT

    player.opponent = dummy
    dummy.opponent = player

    add_child(player)
    add_child(dummy)

    player.died.connect(_on_fighter_died)
    dummy.died.connect(_on_fighter_died)


func _on_fighter_died(f) -> void:
    player.input_enabled = false
    if f == dummy:
        hud.show_banner("KO!  You win\nPress R / Enter to restart")
    else:
        hud.show_banner("Defeated\nPress R / Enter to restart")
