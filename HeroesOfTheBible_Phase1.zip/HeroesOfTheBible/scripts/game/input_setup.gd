class_name InputSetup
extends RefCounted
## Registers the desktop test controls at runtime so project.godot stays
## simple. Safe to call more than once (e.g. after a scene reload).

static func register() -> void:
    _bind("p1_left", [KEY_A, KEY_LEFT])
    _bind("p1_right", [KEY_D, KEY_RIGHT])
    _bind("p1_jump", [KEY_W, KEY_UP, KEY_SPACE])
    _bind("p1_light", [KEY_J])
    _bind("restart", [KEY_R, KEY_ENTER, KEY_KP_ENTER])


static func _bind(action: StringName, keys: Array) -> void:
    if InputMap.has_action(action):
        return
    InputMap.add_action(action)
    for k in keys:
        var ev := InputEventKey.new()
        ev.physical_keycode = k
        InputMap.action_add_event(action, ev)
