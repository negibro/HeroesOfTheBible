class_name Hud
extends CanvasLayer
## Phase 1 HUD: two health bars, names, a center banner and a controls hint.
## Everything is built in code and anchored so it adapts to wider/taller screens.

var _banner: Label


func setup(left: Fighter, right: Fighter) -> void:
    _make_bar(left, true)
    _make_bar(right, false)

    _banner = Label.new()
    _banner.anchor_left = 0.5
    _banner.anchor_right = 0.5
    _banner.anchor_top = 0.5
    _banner.anchor_bottom = 0.5
    _banner.offset_left = -400.0
    _banner.offset_right = 400.0
    _banner.offset_top = -80.0
    _banner.offset_bottom = 80.0
    _banner.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _banner.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    _banner.add_theme_font_size_override("font_size", 64)
    _banner.visible = false
    add_child(_banner)

    var hint := Label.new()
    hint.text = "A/D move   W jump   J light attack   R restart"
    hint.anchor_top = 1.0
    hint.anchor_bottom = 1.0
    hint.offset_left = 40.0
    hint.offset_top = -48.0
    hint.offset_bottom = -16.0
    hint.add_theme_font_size_override("font_size", 20)
    add_child(hint)


func show_banner(text: String) -> void:
    _banner.text = text
    _banner.visible = true


func _make_bar(f: Fighter, on_left: bool) -> void:
    var bar := ProgressBar.new()
    bar.min_value = 0.0
    bar.max_value = float(f.max_health)
    bar.value = float(f.max_health)
    bar.show_percentage = false

    var name_label := Label.new()
    name_label.text = f.fighter_name
    name_label.add_theme_font_size_override("font_size", 24)

    var edge := 0.0 if on_left else 1.0
    var off_l := 40.0 if on_left else -420.0
    var off_r := 420.0 if on_left else -40.0

    bar.anchor_left = edge
    bar.anchor_right = edge
    bar.offset_left = off_l
    bar.offset_right = off_r
    bar.offset_top = 52.0
    bar.offset_bottom = 78.0

    name_label.anchor_left = edge
    name_label.anchor_right = edge
    name_label.offset_left = off_l
    name_label.offset_right = off_r
    name_label.offset_top = 16.0
    name_label.offset_bottom = 48.0
    if not on_left:
        name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT

    add_child(bar)
    add_child(name_label)

    f.health_changed.connect(func(current, _maximum): bar.value = float(current))
